<?php 

 include_once('conf.php');


session_start();

if (isset($_POST['signup'])) {

	$username  = $_POST['email'];
	$pass      = $_POST['password'];
	
	$quer  =  mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' AND password = '$pass' ");

	 $result = mysqli_num_rows($quer);	
	 	
		if($result == 1) {

		$row = mysqli_fetch_assoc($quer);
		
       $_SESSION['username'] = $row['username'];
       $_SESSION['password'] = $row['password'];

       header("location : retrieve.php");
	}
	else{
		echo "Login Failed";
	}
}
 ?>