<?php 
  include_once('conf.php');
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Form Registration</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
	<div class="hd">
		<h3>Welcome to user dashboard</h3>
		<div class="dh">
			<a href="logout.php">Logout</a>
		</div>
		
	</div>
	
   	<hr>
   <div class="ret">
   	  <table border="2">
   	  	<tr>
   	  	<th class="rt">Id</th>
   	  	<th class="rt">Full Name</th>
   	  	<th class="rt">Email</th>
   	  	<th class="rt">Gender</th>
   	  	<th class="rt">Phone Number</th>
   	  	</tr>
   	  <?php 
     
      $sql_query  = mysqli_query($conn, "SELECT * FROM users");
      while ($data = mysqli_fetch_array($sql_query)) {
      	
      
   	 ?>
        <tr>
         <td><?php echo $data['id']; ?></td>
   	  	<td><?php echo $data['fname']; ?></td>
   	  	<td><?php echo $data['email']; ?></td>
   	  	<td><?php echo $data['gender']; ?></td>
   	  	<td><?php echo $data['pno']; ?></td>
         </tr>
         <?php } ?>
   	  </table>
   </div>
</body>
</html>