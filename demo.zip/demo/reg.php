<?php 

  include_once('conf.php');

  session_start();

  if (isset($_POST['signup'])) {
  	

  	$name  =  $_POST['fname'];
  	$ema   =  $_POST['email'];
  	$gend  =  $_POST['gender'];
  	$pnumber = $_POST['pno'];
  	$pass  =  $_POST['password'];

   $quer   = mysqli_query($conn, "INSERT INTO users(fname, email, gender, pno, password) VALUES('$name', '$ema', '$gend', '$pnumber', '$pass')");

   if ($quer > 0) {
   	
   	header("location:retrieve.php");
   }
  else{
  	echo "Your not registered";
  }

  }


 ?>
 <!DOCTYPE html>
 <html>
 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
   <link rel="stylesheet" type="text/css" href="index.css">
 </head>
 <body>
  <div class="dh">
     <form method="POST" class="form-reg">
        <fieldset>
         <legend>Register here</legend>
         <input type="text" name="fname" placeholder="Enter Full name" required><br><br>
         <input type="email" name="email" placeholder="Enter Email" required><br><br>
         <input type="text" name="gender" placeholder="Enter Gender" required><br><br>
         <input type="number" name="pno" placeholder="Enter Phone number" required><br><br>
         <input type="password" name="password" required placeholder="Enter Password"><br><br>
         <button type="submit" name="signup">Register</button>
      </fieldset>
     </form>
  </div>
 </body>
 </html>