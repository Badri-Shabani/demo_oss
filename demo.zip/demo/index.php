<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Form Registration</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
	<div class="dh">
		<form action="login.php" method="POST" class="form-reg">
   	  <fieldset>
   	  	 <legend>Please Login here</legend>
   	  	 <input type="email" name="email" placeholder="Enter Email" required><br><br>
   	  	 <input type="password" name="password" placeholder="Enter Password" required><br><br>
   	  	 <button type="submit" name="signup">Login</button><br><br>
   	  	 Have no account? <a href="reg.php">Sign up</a>
   	  </fieldset>
   </form>
	</div>
</body>
</html>